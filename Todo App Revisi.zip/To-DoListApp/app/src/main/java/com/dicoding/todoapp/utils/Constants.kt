package com.dicoding.todoapp.utils

const val TASK_ID = "TASK_ID"
const val NOTIFICATION_CHANNEL_ID = "notify-task"
